SWEP.Base = "vuvuzela_base" 

SWEP.PrintName = "Small Vuvuzela"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.Pitch = 160
SWEP.Size = 0.5
SWEP.RandomPitch = 10

if SERVER then AddCSLuaFile("shared.lua") end