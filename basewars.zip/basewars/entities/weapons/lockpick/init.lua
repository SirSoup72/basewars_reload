AddCSLuaFile ("cl_init.lua");
AddCSLuaFile ("shared.lua");
 
include ("shared.lua");
 
SWEP.Weight = 4;
SWEP.AutoSwitchTo = true;
SWEP.AutoSwitchFrom = false;