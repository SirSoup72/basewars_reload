
include('shared.lua')

SWEP.PrintName			= "Manhack Gun"			
SWEP.Slot				= 3
SWEP.SlotPos			= 1
SWEP.DrawAmmo			= false
SWEP.DrawCrosshair		= true
