SWEP.Base = "vuvuzela_base" 

SWEP.PrintName = "Normal Vuvuzela"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.Pitch = 100
SWEP.Size = 1
SWEP.RandomPitch = 10

if SERVER then AddCSLuaFile("shared.lua") end