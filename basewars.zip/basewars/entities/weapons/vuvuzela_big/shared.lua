SWEP.Base = "vuvuzela_base" 

SWEP.PrintName = "Big Vuvuzela"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true

SWEP.Pitch = 40
SWEP.Size = 2
SWEP.RandomPitch = 0

if SERVER then AddCSLuaFile("shared.lua") end