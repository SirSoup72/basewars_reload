
ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Lamp"
ENT.Author = "Llamalords/ Gary"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={100,27,0}
// used by gamemode for power plant
ENT.Power		= 0