ENT.Type = "anim"
ENT.Base = "base_drug"
ENT.PrintName = "Food"
ENT.Author = "An aimbotting jackass, or someone who has an aimbotting jackass stealing his name"
ENT.Spawnable = false
ENT.AdminSpawnable = false
