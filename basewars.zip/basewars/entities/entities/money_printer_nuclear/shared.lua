ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Nuclear Money Printer"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={1000,27,0}
// used by gamemode for power plant
ENT.Power		= 5