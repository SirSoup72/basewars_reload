ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Drug Refinery"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={250,35,-19.5}
// used by gamemode for power plant
ENT.Power		= 2