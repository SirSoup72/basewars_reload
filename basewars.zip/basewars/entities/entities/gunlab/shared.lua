ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Gun Lab"
ENT.Author = "Either an aimbotting mingebag, or someone who was impersonated by an aimbotting mingebag"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={2000,20,-45}
ENT.HealthOffset=7
// used by gamemode for power plant
ENT.Power		= 0