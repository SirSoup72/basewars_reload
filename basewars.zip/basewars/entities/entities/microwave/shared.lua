ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Microwave"
ENT.Author = "Either some aimbotting jackass, or someone with an aimbotting jackass pretending to be them."
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={300,35,0}
// used by gamemode for power plant
ENT.Power		= 1
ENT.SparkPos = Vector(0,0,25)