ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Gun Vault"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
