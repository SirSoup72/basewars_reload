ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Radar Tower"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={200,35,0}
// used by gamemode for power plant
ENT.Power		= 3