ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Moonshine Still"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={100,35,0}
// used by gamemode for power plant
ENT.Power		= 0
ENT.SparkPos = Vector(0,0,54)