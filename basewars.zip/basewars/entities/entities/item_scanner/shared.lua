 	
ENT.Type 		= "anim"
ENT.Base 		= "base_drug"

ENT.PrintName	= "Scanner"
ENT.Author		= "HLTV Proxy"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false