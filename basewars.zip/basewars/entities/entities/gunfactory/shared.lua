ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Gun Factory"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={200,60,2}
// used by gamemode for power plant
ENT.Power		= 3
ENT.SparkPos = Vector(-30,-30,60)