include("shared.lua")

language.Add("ent_mad_charge", "Explosive Charge")

/*---------------------------------------------------------
   Name: ENT:Draw()
---------------------------------------------------------*/
function ENT:Draw()

	self.Entity:DrawModel()
end