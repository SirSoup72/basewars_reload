 	
ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "lolbored"
ENT.Author		= "???"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false