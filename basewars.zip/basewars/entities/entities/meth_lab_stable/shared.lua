ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Stable Meth lab"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRadius		= 45
ENT.MaxDamage			= 50
ENT.HealthRing={300,45,4}
// used by gamemode for power plant
ENT.Power		= 0
ENT.SparkPos=Vector(-43,0,12)
ENT.SparkPos2=Vector(43,0,12)
ENT.SparkPos3=Vector(0,-43,12)
ENT.SparkPos4=Vector(0,43,12)