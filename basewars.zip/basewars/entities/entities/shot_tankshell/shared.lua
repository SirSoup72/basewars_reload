 	
ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "STFU Tank Shell"
ENT.Author		= "HLTV Proxy"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false