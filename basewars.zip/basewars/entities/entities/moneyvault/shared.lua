ENT.Type = "anim";
ENT.Base = "base_structure"
ENT.PrintName = "Money Vault"
ENT.Author = "Helix Nebula";
ENT.HealthRing={1000,30,-23}

ENT.Spawnable = false;
ENT.AdminSpawnable = false;