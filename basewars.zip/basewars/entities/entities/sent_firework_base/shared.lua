ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "Firework"
ENT.Author			= "TurtleHax/LinkTwilight"
ENT.Information		= "*BOOM* *FIZZLE*"
ENT.Category		= "Fireworks"
	
ENT.Spawnable			= false
ENT.AdminSpawnable		= false
