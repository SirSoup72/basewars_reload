ENT.Type 			= "anim" 
ENT.Base 			= "base_anim" 
ENT.PrintName	 = "Lua Scoreboard"
ENT.Author		 = "kopimi"
ENT.Contact		 = "regan.flow@gmail.com"
ENT.Purpose 	 = "A scoreboard for your server"
ENT.Spawnable	 = false
ENT.AdminSpawnable = false
