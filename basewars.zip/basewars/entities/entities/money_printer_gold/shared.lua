ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Gold Money Printer"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={400,27,0}
// used by gamemode for power plant
ENT.Power		= 2