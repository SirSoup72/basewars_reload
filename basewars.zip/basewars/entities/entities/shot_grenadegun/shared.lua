 	
ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "Grenade Launcher grenade"
ENT.Author		= "???"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false