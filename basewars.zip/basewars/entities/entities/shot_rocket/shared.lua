 	
ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "Rocket Launcher rocket"
ENT.Author		= "???"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false