 	
ENT.Type 		= "anim"
ENT.Base 		= "base_drug"

ENT.PrintName	= "Amplifier"
ENT.Author		= "HLTV Proxy"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false