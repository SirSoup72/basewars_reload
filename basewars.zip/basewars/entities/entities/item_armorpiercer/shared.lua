 	
ENT.Type 		= "anim"
ENT.Base 		= "base_drug"

ENT.PrintName	= "Pain Killer"
ENT.Author		= "HLTV Proxy"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false