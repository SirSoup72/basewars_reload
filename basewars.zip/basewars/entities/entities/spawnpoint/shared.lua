ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Spawn Point"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={100,50,1}
ENT.HealthAxis=true
// used by gamemode for power plant
ENT.Power		= 0