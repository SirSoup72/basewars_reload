
ENT.Base = "base_anim"
ENT.Type = "anim"


ENT.PrintName		= "Xenon Ad"
ENT.Author			= ""
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= true
