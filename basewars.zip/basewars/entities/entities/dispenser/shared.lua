ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Ammo Dispenser"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={500,30,-34.5}
// used by gamemode for power plant
ENT.Power		= 0
ENT.SparkPos = Vector(0,0,30)