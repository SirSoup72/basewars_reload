ENT.Type 		= "anim"
ENT.PrintName	= "Rocket"
ENT.Author		= "Worshipper"
ENT.Contact		= "Josephcadieux@hotmail.com"