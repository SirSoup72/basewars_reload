ENT.Type 			= "anim"
ENT.Base 			= "sent_firework_base"
ENT.PrintName		= "Red"
ENT.Author			= "TurtleHax/LinkTwilight"
ENT.Information		= "A simple red firework."
	
ENT.Spawnable			= false
ENT.AdminSpawnable		= true
