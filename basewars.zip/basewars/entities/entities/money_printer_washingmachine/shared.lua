ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Washing Machine Money Printer"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={200,45,-20}
// used by gamemode for power plant
ENT.Power		= 1
ENT.SparkPos = Vector(-20,-25,15)