
include('shared.lua')
function ENT:DrawEntityOutline( size )
end