 	
ENT.Type 		= "anim"
ENT.Base 		= "base_gmodentity"

ENT.PrintName	= "Auto Turret Body"
ENT.Author		= "???"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false