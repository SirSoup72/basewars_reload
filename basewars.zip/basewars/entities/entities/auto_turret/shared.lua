 	
ENT.Type 		= "anim"
ENT.Base 		= "base_structure"

ENT.PrintName	= "Sentry Turret"
ENT.Author		= "HLTV Proxy"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
ENT.HealthRing={300,30,-16.5}
// used by gamemode for power plant
ENT.Power		= 1
