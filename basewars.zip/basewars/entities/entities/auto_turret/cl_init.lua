
include('shared.lua')

ENT.RenderGroup 		= RENDERGROUP_OPAQUE

function ENT:GetOverlayText()

	return self:GetPlayerName()	
	
end
