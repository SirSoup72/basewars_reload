-- ============================================
-- =                                          =
-- =          Crate SENT by Mahalis           =
-- =                                          =
-- ============================================

// copy pasta from DURG lab

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

function ENT:Initialize()
	self:SetModel( "models/props_c17/consolebox03a.mdl" )
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetColor(Color(255, 255, 255, 255))
	local phys = self:GetPhysicsObject()
	
	if(phys:IsValid()) then phys:Wake() end
	timer.Create( tostring(self), 68, 0, function() self:giveMoney() end)
	timer.Create( tostring(self) .. "fuckafkfags", 1200, 1, function() self:shutOff() end)
	timer.Create( tostring(self) .. "notifyoff", 1000, 1, function() self:notifypl() end)
	self:SetNWBool("sparking",false)
	self:SetNWInt("damage",200)
	self:SetNWInt("upgrade", 0)
	local ply = self.Owner
	ply:GetTable().maxSilverPrinter=ply:GetTable().maxSilverPrinter + 1
	self.Inactive = false
	self.NearInact = false
	self:SetNWInt("power",0)
	self.Payout = {10000, "Silver Money Printer"}
end

function ENT:giveMoney()
	local ply = self.Owner
	if(IsValid(ply) && !self.Inactive && self:IsPowered()) then
		// ply:AddMoney( 25 );
		
		local trace = { }
		
		trace.start = self:GetPos()+self:GetAngles():Up()*15;
		trace.endpos = trace.start + self:GetAngles():Forward() + self:GetAngles():Right()
		trace.filter = self
		
		local tr = util.TraceLine( trace );
		local amount = math.random( 820, 1100 )
		if (self:GetNWInt("upgrade")==2) then
			amount = math.random( 1815, 1925 )
		elseif (self:GetNWInt("upgrade")==1) then
			amount = math.random( 1100, 1375 )
		end

		local moneybag = ents.Create( "prop_moneybag" );
		moneybag:SetModel( "models/props/cs_assault/money.mdl" );
		moneybag:SetPos( tr.HitPos );
		moneybag:SetAngles(self:GetAngles())
		moneybag:Spawn();
		moneybag:SetColor(Color(200,255,200,255))
		moneybag:SetMoveType( MOVETYPE_VPHYSICS )		
		moneybag:GetTable().MoneyBag = true;
		moneybag:GetTable().Amount = amount
		
		
		Notify( ply, 0, 3, "Counterfeit money printer created $" .. amount );
	elseif (self.Inactive) then
		Notify( ply, 4, 3, "A money printer is inactive, press use on it to make it active again." );
	elseif !self:IsPowered() then
		Notify(ply, 4, 3, "A money printer does not have enough power. Get a power plant.")
	end
end

function ENT:shutOff()
	local ply = self.Owner
	self.Inactive = true
	Notify( ply, 1, 3, "NOTICE: A MONEY PRINTER HAS GONE INACTIVE" );
	Notify( ply, 1, 3, "PRESS USE ON IT TO CONTINUE GETTING MONEY" );
	self:SetColor(Color(255,0,0,254))
end
function ENT:notifypl()
	self.NearInact = true
	local ply = self.Owner
	Notify( ply, 4, 3, "NOTICE: A MONEY PRINTER IS ABOUT TO GO INACTIVE" );
	Notify( ply, 4, 3, "PRESS USE ON IT TO PREVENT THIS" );
	self:SetColor(Color(255,150,150,254))
end

function ENT:Use(activator,caller)
	local ply = self.Owner
	if (self.NearInact==true && activator==ply && self:GetNWBool("sparking")==false && ply:CanAfford(40)) then
		ply:AddMoney( -40 )
		self.NearInact = false
		self:SetNWBool("sparking",true)
		timer.Create( tostring(self) .. "resupply", 1, 1, function() self:Reload() end)
		
	end
end

function ENT:Reload()
	Notify(self.Owner, 0, 3, "Counterfeit money printer resupplied")
	timer.Destroy( tostring(self) .. "fuckafkfags")
	timer.Create( tostring(self) .. "fuckafkfags", 250, 1, function() self:shutOff() end)
	timer.Destroy( tostring(self) .. "notifyoff")
	timer.Create( tostring(self) .. "notifyoff", 200, 1, function() self:notifypl() end)
	self.Inactive = false
	self.NearInact = false
	self:SetColor(Color(230, 232, 250, 254))
	local drugPos = self:GetPos()
	self:SetNWBool("sparking",false)
end
 
function ENT:Think()
	if (IsValid(self.Owner)==false) then
		self:Remove()
	end
end

function ENT:OnRemove( )
	timer.Destroy(tostring(self)) 
	timer.Destroy(tostring(self) .. "fuckafkfags")
	timer.Destroy(tostring(self) .. "notifyoff")
	local ply = self.Owner
	if IsValid(ply) then
		ply:GetTable().maxSilverPrinter=ply:GetTable().maxSilverPrinter - 1
	end
end

