ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Broze Money Printer"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={100,27,0}
// used by gamemode for power plant
ENT.Power		= 1