ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Pill Box"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={300,30,-16.5}