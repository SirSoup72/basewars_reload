ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Plant"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={110,16,1}
// used by gamemode for power plant
ENT.Power		= 0