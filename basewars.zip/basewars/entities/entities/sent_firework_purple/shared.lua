ENT.Type 			= "anim"
ENT.Base 			= "sent_firework_base"
ENT.PrintName		= "Purple"
ENT.Author			= "TurtleHax/LinkTwilight"
ENT.Information		= "A simple purple firework."
	
ENT.Spawnable			= false
ENT.AdminSpawnable		= true
