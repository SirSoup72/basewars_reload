include('shared.lua')

function ENT:DrawEntityOutline( size )
	// fuck the outline, yet i still wanna use the base ent, and i dont feel like looking up the thing calling this because im lazy.
end

