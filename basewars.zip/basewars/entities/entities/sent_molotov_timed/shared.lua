ENT.Type 		= "anim"
ENT.Base 		= "base_anim"

ENT.PrintName	= "Molotov_timed"
ENT.Author		= "Pac_187"
ENT.Contact		= ""


