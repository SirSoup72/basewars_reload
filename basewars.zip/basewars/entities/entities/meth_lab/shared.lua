ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Unstable Meth Lab"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRadius		= 45
ENT.MaxDamage			= 200
ENT.HealthRing={200,45,1}
// used by gamemode for power plant
ENT.Power		= 0
ENT.SparkPos=Vector(40,0,40)