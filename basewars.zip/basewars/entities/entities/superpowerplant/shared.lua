ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Super Power Plant"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={300,50,2}
// power plant doesnt drain any power.
ENT.Power		= 0