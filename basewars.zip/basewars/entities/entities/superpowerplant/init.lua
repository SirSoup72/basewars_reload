-- ============================================
-- =                                          =
-- =          Crate SENT by Mahalis           =
-- =                                          =
-- ============================================

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

function ENT:Initialize()

	self.Entity:SetModel("models/MaxOfS2D/hover_propeller.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Entity:SetColor(Color(255, 255, 255, 255))
	local phys = self.Entity:GetPhysicsObject()
	if(phys:IsValid()) then phys:Wake() end
	self.Entity:SetNWInt("damage",300)
	self.Entity:SetNWInt("upgrade", 0)
	local ply = self.Owner
	ply:GetTable().maxgenerator=ply:GetTable().maxgenerator + 1
	self.Inactive = false
	self.Powdist=1024
	self.Entity:SetNWEntity("socket1",nil)
	self.Entity:SetNWEntity("socket2",nil)
	self.Entity:SetNWEntity("socket3",nil)
	self.Entity:SetNWEntity("socket4",nil)
	self.Entity:SetNWEntity("socket5",nil)
	self.Entity:SetNWEntity("socket6",nil)
	self.Entity:SetNWEntity("socket7",nil)
	self.Entity:SetNWEntity("socket8",nil)
	self.Entity:SetNWEntity("socket9",nil)
	self.Entity:SetNWEntity("socket10",nil)
	
	self.Panel1 = ents.Create("prop_dynamic_override")
	self.Panel1:SetModel( "models/MaxOfS2D/hover_propeller.mdl" )
	self.Panel1:SetPos(self.Entity:GetPos()+self.Entity:GetAngles():Forward()*0+self.Entity:GetAngles():Right()*15+self.Entity:GetAngles():Up()*0)
	self.Panel1:SetAngles(Angle(0,0,0))
	self.Panel1:SetParent(self.Entity)
	self.Panel1:SetSolid(SOLID_NONE)
	self.Panel1:SetColor(Color(255, 255, 255, 255))
	self.Panel1:SetMoveType(MOVETYPE_NONE)
	
	self.Panel2 = ents.Create("prop_dynamic_override")
	self.Panel2:SetModel( "models/props_lab/reciever01d.mdl" )
	self.Panel2:SetPos(self.Entity:GetPos()+self.Entity:GetAngles():Forward()*10+self.Entity:GetAngles():Right()*7+self.Entity:GetAngles():Up()*15)
	self.Panel2:SetAngles(Angle(0,0,0))
	self.Panel2:SetParent(self.Entity)
	self.Panel2:SetSolid(SOLID_NONE)
	self.Panel2:SetMoveType(MOVETYPE_NONE)
	self.Panel2:SetColor(Color(255, 255, 255, 255))
	
	self.Panel3 = ents.Create("prop_dynamic_override")
	self.Panel3:SetModel( "models/props_lab/reciever01d.mdl" )
	self.Panel3:SetPos(self.Entity:GetPos()+self.Entity:GetAngles():Forward()*13+self.Entity:GetAngles():Right()*7+self.Entity:GetAngles():Up()*10)
	self.Panel3:SetAngles(Angle(140,0,0))
	self.Panel3:SetParent(self.Entity)
	self.Panel3:SetSolid(SOLID_NONE)
	self.Panel3:SetMoveType(MOVETYPE_NONE)
	self.Panel3:SetColor(Color(255, 255, 255, 255))
	
	self.scrap = false
	timer.Create( tostring(self.Entity), 60, 0, function() self:giveMoney() end)
	timer.Create( tostring(self.Entity) .. "fuckafkfags", 1200, 1, function() self:shutOff() end)
	timer.Create( tostring(self.Entity) .. "notifyoff", 1080, 1, function() self:notifypl() end)
end

function ENT:giveMoney()
	local ply = self.Owner
	if(IsValid(ply) && !self.Inactive) then
		if ply:CanAfford(5) then
			ply:AddMoney( -5 );
			Notify( ply, 2, 3, "$5 spent to keep Generator running." );
		else
			Notify( ply, 4, 3, "Generator has shut off from lack of money" )
			self.Entity:shutOff()
			timer.Destroy( tostring(self.Entity) .. "fuckafkfags")
			timer.Destroy( tostring(self.Entity) .. "notifyoff")
		end
	elseif (self.Inactive) then
		Notify( ply, 4, 3, "A Generator is inactive, press use on it to make it active again." );
	end
end

function ENT:shutOff()
	local ply = self.Owner
	self.Inactive = true
	Notify( ply, 1, 3, "NOTICE: A GENERATOR HAS GONE INACTIVE" );
	Notify( ply, 1, 3, "PRESS USE ON IT TO MAKE IT WORK AGAIN" );
	self.Entity:SetColor(Color(255,0,0,255))
end
function ENT:notifypl()
	local ply = self.Owner
	Notify( ply, 4, 3, "NOTICE: A GENERATOR IS ABOUT TO GO INACTIVE" );
	Notify( ply, 4, 3, "PRESS USE ON IT TO KEEP IT WORKING" );
	self.Entity:SetColor(Color(255,150,150,255))
end

function ENT:Use(activator,caller)
	if activator:CanAfford(5) && activator==self.Owner then
		timer.Destroy( tostring(self.Entity) .. "fuckafkfags")
		timer.Create( tostring(self.Entity) .. "fuckafkfags", 1200, 1, function() self:shutOff() end)
		timer.Destroy( tostring(self.Entity) .. "notifyoff")
		timer.Create( tostring(self.Entity) .. "notifyoff", 1080, 1, function() self:notifypl() end)
		self.Inactive = false
		self.Entity:SetColor(Color(255,255,255,255))
	end
end

function ENT:createDrug()
	local drugPos = self.Entity:GetPos()
	drug = ents.Create("item_drug")
	drug:SetPos(Vector(drugPos.x,drugPos.y,drugPos.z + 10))
	drug:Spawn()
	self.Entity:SetNWBool("sparking",false)
end
 
function ENT:Think()
	if (IsValid(self.Owner)==false) then
		self.Entity:Remove()
	end
	self.Entity:UpdateSockets()
	self.Entity:NextThink(CurTime()+1)
	return true
end

function ENT:OnRemove( )
	self.Entity:UnSocket()
	timer.Destroy(tostring(self.Entity)) 
	timer.Destroy(tostring(self.Entity) .. "fuckafkfags")
	timer.Destroy(tostring(self.Entity) .. "notifyoff")
	local ply = self.Owner
	if IsValid(ply) then
		ply:GetTable().maxgenerator=ply:GetTable().maxgenerator - 1
	end
end

function ENT:UpdateSockets()
	if self.Inactive then
		self.Entity:UnSocket()
		for i=1,10,1 do
			self.Entity:SetNWEntity("socket"..tostring(i),ents.GetByIndex(0))
		end
	else
		for i=1,10,1 do
			if !IsValid(self.Entity:GetNWEntity("socket"..tostring(i))) then
				local newstructure = self.Entity:FindStructure()
				if IsValid(newstructure) then
					self.Entity:SetNWEntity("socket"..tostring(i), newstructure)
					newstructure:SetNWInt("power", newstructure:GetNWInt("power")+1)
				end
			end
		end
		for i=1,10,1 do
			if IsValid(self.Entity:GetNWEntity("socket"..tostring(i))) && self.Entity:GetNWEntity("socket"..tostring(i)):GetPos():Distance(self.Entity:GetPos())>self.Powdist then
				self.Entity:GetNWEntity("socket"..tostring(i)):SetNWInt("power", self.Entity:GetNWEntity("socket"..tostring(i)):GetNWInt("power")-1)
				// since it doesnt want to send a nil, or itself, well just "ground it out" so to speak.
				self.Entity:SetNWEntity("socket"..tostring(i),ents.GetByIndex(0))
			end
		end
	end
end

function ENT:FindStructure()
	for k, v in pairs( ents.FindInSphere(self.Entity:GetPos(), self.Powdist)) do
		if v:GetTable().Structure && v:GetNWInt("power")<v:GetTable().Power && v:GetPos():Distance(self.Entity:GetPos())<=self.Powdist then
			return v
		end
	end
	return nil
end


function ENT:MakeScraps()
--	if !self.scrap then
--		self.scrap = false
--		local value = CfgVars["generatorcost"]/8
--		if value<5 then value = 5 end
--		for i=0, 5, 1 do
--			local scrapm = ents.Create("scrapmetal")
--			scrapm:SetModel( "models/gibs/metal_gib" .. math.random(1,5) .. ".mdl" );
--			local randpos = Vector(math.random(-5,5), math.random(-5,5), math.random(0,5))
--			scrapm:SetPos(self.Entity:GetPos()+randpos)
--			scrapm:Spawn()
--			scrapm:GetTable().ScrapMetal = true
--			scrapm:GetTable().Amount = math.random(3,value)
--			scrapm:Activate()
--			scrapm:GetPhysicsObject():SetVelocity(randpos*35)
--			
--			timer.Create( "scraptimer" ..i, 10, 1, function(removeme)
--				removeme:Remove()
--			end, scrapm )
--
--			
--		end 
--	end
end

function ENT:UnSocket()
	for i=1,10,1 do
		if IsValid(self.Entity:GetNWEntity("socket"..tostring(i))) then
			self.Entity:GetNWEntity("socket"..tostring(i)):SetNWInt("power", self.Entity:GetNWEntity("socket"..tostring(i)):GetNWInt("power")-1)
		end
	end
end