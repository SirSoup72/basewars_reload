ENT.Type = "anim"
ENT.Base = "base_drug"
ENT.PrintName = "Booze"
ENT.Author = "Rickster"
ENT.Spawnable = false
ENT.AdminSpawnable = false
