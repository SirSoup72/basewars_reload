 	
ENT.Type 		= "anim"
ENT.Base 		= "base_drug"

ENT.PrintName	= "Knockback"
ENT.Author		= "HLTV Proxy"
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false