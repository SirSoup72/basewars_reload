ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Drug Refinery"
ENT.Author = "HLTV Proxy"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={250,0,0}
// used by gamemode for power plant
ENT.Power		= 0