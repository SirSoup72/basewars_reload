ENT.Type = "anim"
ENT.Base = "base_structure"
ENT.PrintName = "Drug Lab"
ENT.Author = "Rickster"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.HealthRing={100,27,0}
// used by gamemode for power plant
ENT.Power		= 0
ENT.SparkPos = Vector(0,0,20)