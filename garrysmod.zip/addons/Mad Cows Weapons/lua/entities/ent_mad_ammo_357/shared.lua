ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= ".357 AMMO BOX"
ENT.Author			= "Worshipper"
ENT.Information		= ""
ENT.Category		= "Mad Cows Weapons"

ENT.Spawnable		= true
ENT.AdminSpawnable	= true
