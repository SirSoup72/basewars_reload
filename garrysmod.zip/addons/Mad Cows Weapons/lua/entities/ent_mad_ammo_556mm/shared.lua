ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "5.56MM AMMO BOX"
ENT.Author			= "Worshipper"
ENT.Information		= ""
ENT.Category		= "Mad Cows Weapons"

ENT.Spawnable		= true
ENT.AdminSpawnable	= true
