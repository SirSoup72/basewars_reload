include('shared.lua')

SWEP.PrintName			= "Mad Cows Shotgun Base"			// 'Nice' Weapon name (Shown on HUD)	
SWEP.Slot				= 2							// Slot in the weapon selection menu
SWEP.SlotPos			= 1							// Position in the slot