--Chat Tags by Tyguy
CreateClientConVar("chat_tags_color_r", 255, true, false)
CreateClientConVar("chat_tags_color_g", 255, true, false)
CreateClientConVar("chat_tags_color_b", 255, true, false)
CreateClientConVar("chat_tags_color_a", 255, true, false)
local Var = math.abs( math.sin( CurTime() * 2 ) )
local Tags = 
{
--Group    --Tag     --Color
{"admin", "[Admin] ", Color(0, 0, 255, 255) },
{"superadmins", "[Head Admin] ", Color(220, 0, 255, 255) },
{"community director", "[Community Director] ", Color(0, 75, 17, 255) },
{"moderator", "[Moderator] ", Color(63, 79, 129, 255) },
{"diamondvip", "[Diamond VIP] ", Color(44, 206, 204, 158) },
{"extremevip", "[Extreme VIP] ", Color(0, 31, 127, 255) },
{"silvervip", "[Silver VIP] ", Color(150, 150, 150, 255) },
{"server manager", "[Server Manager] ", Color(0, 0, 0, 0)},
{"trialmod", "[Trial Moderator] ", Color(0, 0, 255, 255) },
{"headadmin", "[Head Admin] ", Color(127, 0, 255, 255) },
{"owner", "[Owner] ", Color(170, 45, 60, Var * 255) },
{"superadmin", "[Co-Owner] ", Color(Var * 127, Var * 255, Var * 0, Var * 255) },
{"trialmoderator", "[Trial Mod] ", Color(0,119,255,255) }
}

hook.Add("OnPlayerChat", "Tags", function(ply, strText, bTeamOnly)
	if IsValid(ply) and ply:IsPlayer() then
		for k,v in pairs(Tags) do
			if ply:IsUserGroup(v[1]) then
			local R = GetConVarNumber("chat_tags_color_r")
			local G = GetConVarNumber("chat_tags_color_g")
			local B = GetConVarNumber("chat_tags_color_b")
			local A = GetConVarNumber("chat_tags_color_a")
			local nickteam = team.GetColor(ply:Team())
				if !bTeamOnly then
				chat.AddText(v[3], v[2], nickteam, ply:Nick(), color_white, ": ", color_white, strText)
				return true
				else
				local Var = math.abs( math.sin( CurTime() * 2 ) )
				chat.AddText(v[3], v[2], nickteam, "(TEAM) ", ply:Nick(), color_white, ": ", Color(R, G, B, A), strText)
				return true
				end
			end
		end
	end
	if !IsValid(ply) and !ply:IsPlayer() then
	local ConsoleColor = Color(0, 255, 0) --Change this to change Console name color
	chat.AddText(ConsoleColor, "Console", color_white, ": ", strText)
	return true
	end
end )