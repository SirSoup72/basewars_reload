-- Configuration
local Config = {
	Enabled = true,
	
	DistanceMin = 200,
	DistanceMax = 500,
	
	Background = Color( 50, 50, 50 ),
	Foreground = Color( 255, 255, 255 ),
	Border = Color( 100, 200, 255 ),
	
	ShowAdmin = true,
	Large = true,
	ThroughWalls = false,
	TeamColours = true
}
-- End config

if SERVER then
	AddCSLuaFile()
else

	local function CalculateFade( pl )
		local distance = pl:GetPos():Distance( LocalPlayer():EyePos() )
		local min, max = Config.DistanceMin, Config.DistanceMax
		
		return math.Clamp( ( max - distance ) / ( max - min ), 0, 1 )
	end
	
	local AvatarImages = {}
	local function GetAvatarImage( pl )
		if ( not AvatarImages[ pl ] ) then
			AvatarImages[ pl ] = vgui.Create( "AvatarImage" )
			AvatarImages[ pl ]:SetSize( 32, 32 )
			AvatarImages[ pl ]:SetPlayer( pl )
		end
		
		return AvatarImages[ pl ]
	end
	
	local plicon = Material( "icon16/user.png" )
	local admin = Material( "icon16/shield.png" )
	local function RenderPlayerTag( pl )
		local fade = CalculateFade( pl )
		
		if ( fade > 0 ) then
			local pos = pl:GetPos() + Vector( 0, 0, 80 )
			local trace = {
				start = LocalPlayer():EyePos(),
				endpos = pos,
				filter = { LocalPlayer(), pl }
			}
			
			if ( not util.TraceLine( trace ).Hit or Config.ThroughWalls ) then
				local screenpos = pos:ToScreen()
				
				if ( screenpos.visible ) then
					local border = table.Copy( Config.Border )
					local background = table.Copy( Config.Background )
					local foreground = table.Copy( Config.Foreground )
					local large = Config.Large
					
					if ( Config.TeamColours ) then
						foreground = team.GetColor( pl:Team() )
					end
					
					foreground.a = foreground.a * fade
					background.a = background.a * fade
					border.a = border.a * fade
					
					surface.SetFont( "DermaDefaultBold" )
					local textwidth = surface.GetTextSize( pl:Name() )
					
					if ( large ) then
						surface.SetFont( "Default" )
						local teamwidth = surface.GetTextSize( team.GetName( pl:Team() ) )
						if ( teamwidth > textwidth ) then
							textwidth = teamwidth
						end
					end
					
					local picsize = large and 32 or 16
					local w = 5 + picsize + 5 + 5 + textwidth
					local h = 5 + picsize + 5
					local x, y = screenpos.x - w / 2, screenpos.y - h / 2
					
					surface.SetDrawColor( background )
					surface.DrawRect( x, y, w, h )
					
					surface.SetDrawColor( border )
					surface.DrawOutlinedRect( x + 1, y + 1, w - 2, h - 2 )
					
					local avatar = GetAvatarImage( pl )
					
					if ( large ) then				
						avatar:SetVisible( true )
						avatar:SetPos( x + 5, y + 5 )
					else
						if ( pl:IsAdmin() and Config.ShowAdmin ) then
							surface.SetMaterial( admin )
						else
							surface.SetMaterial( plicon )
						end
						surface.SetDrawColor( Color( 255, 255, 255, fade * 255 ) )
						surface.DrawTexturedRect( x + 5, y + 5, 16, 16 )
						
						avatar:SetVisible( false )
					end
					
					draw.SimpleTextOutlined( pl:Name(), "DermaDefaultBold", x + 5 + picsize + 5, y + 5, foreground, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, Color( 0, 0, 0, fade * 255 ) )
					
					if ( large ) then
						draw.SimpleTextOutlined( team.GetName( pl:Team() ), "Default", x + 5 + picsize + 5, y + h - 8, foreground, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, fade * 255 ) )
					end
					
					return
				end
			end
		end
		
		GetAvatarImage( pl ):SetVisible( false )
	end
	
	hook.Add( "HUDPaint", "DrawPlayerTags", function()
		for _, pl in ipairs( player.GetAll() ) do
			if ( IsValid( pl ) and pl ~= LocalPlayer() ) then
				RenderPlayerTag( pl )
			end
		end
		
		for pl, image in pairs( AvatarImages ) do
			if ( not IsValid( pl ) ) then
				AvatarImages[ pl ]:Remove()
				AvatarImages[ pl ] = nil
			end
		end
	end )
end