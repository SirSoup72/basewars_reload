ENT.Type 				= "anim"
ENT.Base 				= "ent_cs_ammo_base"
ENT.PrintName 			= ".357 SIG (12)"
ENT.Author 				= ""
ENT.Information 		= ""

ENT.Spawnable 			= true
ENT.AdminSpawnable		= false 
ENT.Category			= "CS:S Ammo"

AddCSLuaFile()

ENT.AmmoType 			= "GaussEnergy"
ENT.AmmoAmount 			= 12
ENT.AmmoModel			= "models/Items/357ammo.mdl"