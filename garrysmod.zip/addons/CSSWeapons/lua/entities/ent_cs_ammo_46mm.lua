ENT.Type 				= "anim"
ENT.Base 				= "ent_cs_ammo_base"
ENT.PrintName 			= "4.6mm (30)"
ENT.Author 				= ""
ENT.Information 		= ""

ENT.Spawnable 			= true
ENT.AdminSpawnable		= false 
ENT.Category			= "CS:S Ammo"

AddCSLuaFile()

ENT.AmmoType 			= "Gravity"
ENT.AmmoAmount 			= 30
ENT.AmmoModel			= "models/Items/BoxSRounds.mdl"