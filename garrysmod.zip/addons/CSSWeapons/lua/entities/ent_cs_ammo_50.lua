ENT.Type 				= "anim"
ENT.Base 				= "ent_cs_ammo_base"
ENT.PrintName 			= ".50 AE (15)"
ENT.Author 				= ""
ENT.Information 		= ""

ENT.Spawnable 			= true
ENT.AdminSpawnable		= false 
ENT.Category			= "CS:S Ammo"

AddCSLuaFile()

ENT.AmmoType 			= "CombineCannon"
ENT.AmmoAmount 			= 15
ENT.AmmoModel			= "models/Items/BoxSRounds.mdl"