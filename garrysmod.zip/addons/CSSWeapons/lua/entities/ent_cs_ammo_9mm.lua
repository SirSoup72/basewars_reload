ENT.Type 				= "anim"
ENT.Base 				= "ent_cs_ammo_base"
ENT.PrintName 			= "9mm (20)"
ENT.Author 				= ""
ENT.Information 		= ""

ENT.Spawnable 			= true
ENT.AdminSpawnable		= false 
ENT.Category			= "CS:S Ammo"

AddCSLuaFile()

ENT.AmmoType 			= "Battery"
ENT.AmmoAmount 			= 20
ENT.AmmoModel			= "models/Items/BoxSRounds.mdl"