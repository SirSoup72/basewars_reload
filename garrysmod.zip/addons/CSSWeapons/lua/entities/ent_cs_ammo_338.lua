ENT.Type 				= "anim"
ENT.Base 				= "ent_cs_ammo_base"
ENT.PrintName 			= ".338 (40)"
ENT.Author 				= ""
ENT.Information 		= ""

ENT.Spawnable 			= true
ENT.AdminSpawnable		= false 
ENT.Category			= "CS:S Ammo"

AddCSLuaFile()

ENT.AmmoType 			= "SniperRound"
ENT.AmmoAmount 			= 40
ENT.AmmoModel			= "models/Items/BoxMRounds.mdl"